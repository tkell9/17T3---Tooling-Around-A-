﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public abstract class ActionSetupData : ScriptableObject{
    public enum ActionType
    {
        AddResource
    }

    public ActionType Type;
}

public class AddResourceActionData : ActionSetupData
{
    public new ActionType Type = ActionType.AddResource;
    public string ResourceToAdd;
    public float AdditionValue;
    public ResourcePool TargetPool;
}
