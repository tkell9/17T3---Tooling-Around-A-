﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Action : MonoBehaviour {

    public string ActionName;
    public bool HasActionCompleted;
    public ActionSetupData ActionData;

    public abstract void UndertakeAction();
    public abstract void ResetAction();
    public abstract AddResourceActionData RequestDataSetup();
}