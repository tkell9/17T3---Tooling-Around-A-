﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Condition : MonoBehaviour {

    public string Name;
    public ConditionSetUpData Data;

    public abstract void SetupCondition(ConditionSetUpData _SetupData);
    public abstract bool HasConditionBeenFulfilled();
    public abstract void ResetCondition();

    public abstract ObjectOnTriggerEnter2DConditionSetupData RequestDataSetup();
}
