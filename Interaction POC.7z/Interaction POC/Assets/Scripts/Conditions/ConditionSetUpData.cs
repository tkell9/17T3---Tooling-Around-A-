﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public abstract class ConditionSetUpData : ScriptableObject {
    public enum ConditionType
    {
        ObjectOnTriggerEnter2D
    }
    public ConditionType Conditiontype;
    public List<string> ConcerningTags = new List<string>();
}

public class ObjectOnTriggerEnter2DConditionSetupData : ConditionSetUpData
{
    public new ConditionType Conditiontype = ConditionType.ObjectOnTriggerEnter2D;
    public enum Colider2DType { Box, Circle, Capsule }
    public Colider2DType ObjectColider;
}
