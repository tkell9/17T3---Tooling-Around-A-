﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectOnTriggerEnter2DCondition : Condition {

    public bool HasObjectEntered;

    public override void SetupCondition(ConditionSetUpData _SetupData)
    {
        Data = _SetupData;
        ObjectOnTriggerEnter2DConditionSetupData CastData = (ObjectOnTriggerEnter2DConditionSetupData)_SetupData;
        if (CastData == null)
            return;

        ColliderSetup(CastData);
        DestroyObject(_SetupData);
    }

    public override bool HasConditionBeenFulfilled()
    {
        if (HasObjectEntered == true)
            return true;
        return false;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (Data.ConcerningTags.Contains(collision.gameObject.tag))
            HasObjectEntered = true;
        else
            HasObjectEntered = false;
    }


    //
    void ColliderSetup(ObjectOnTriggerEnter2DConditionSetupData _OTESetUpData)
    {
        switch (_OTESetUpData.ObjectColider)
        {
            case ObjectOnTriggerEnter2DConditionSetupData.Colider2DType.Box:
                BoxCollider2D ThisCollider = gameObject.GetComponent<BoxCollider2D>();
                if (ThisCollider == null)
                {
                    ThisCollider = gameObject.AddComponent<BoxCollider2D>();
                    ThisCollider.isTrigger = true;
                }
                else
                {
                    if (ThisCollider.isTrigger == false)
                    {
                        ThisCollider = gameObject.AddComponent<BoxCollider2D>();
                        ThisCollider.isTrigger = true;
                    }
                }
                break;
            case ObjectOnTriggerEnter2DConditionSetupData.Colider2DType.Circle:
                break;
            case ObjectOnTriggerEnter2DConditionSetupData.Colider2DType.Capsule:
                break;
        }
    }

    public override void ResetCondition()
    {
        HasObjectEntered = false;
    }





    //This will be the create window editor.. maybe put this in it's own script... createdata class... or in ConditionSetupData
    public override ObjectOnTriggerEnter2DConditionSetupData RequestDataSetup()
    {
        //
        ObjectOnTriggerEnter2DConditionSetupData ConData = ScriptableObject.CreateInstance<ObjectOnTriggerEnter2DConditionSetupData>();
        ConData.ConcerningTags.Add("Player");
        //Choose appropriate collider.
        ConData.ObjectColider = ObjectOnTriggerEnter2DConditionSetupData.Colider2DType.Box;

        return ConData;
    }
}
